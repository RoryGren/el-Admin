<?php
	include 'config.php';
	include 'classes/classAdmin.php';
	$Today = gmdate("Y-m-d H:i:s", strtotime(" + 2 hours"));
	include 'head.php';
?>