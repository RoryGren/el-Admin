<!-- Modal -->
<div id="modalDiv" class="modal fade" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
				<h4 class="modal-title" id="modal-title">Detail</h4>
			</div>
			<!--<p class="btn-danger text-center" style="margin-bottom: 0px;">Changes made will be implemented immediately.</p>-->
			<div class="modal-body" id="detailModal">
				
				
			</div>
			<div class="modal-footer">
				<button id="btnGreen" type="button" class="btn btn-success hidden" data-dismiss="modal">Green</button>
				<button id="btnRed"   type="button" class="btn btn-danger hidden" data-dismiss="modal">Red</button>
				<button id="btnWhite" type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>

	</div>
</div>
