<?php

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * Description of classCourse
 *
 * @author rory
 */
class classCourse {

	//put your code here
	public function __construct() {
//		self::function();
	}

}

?>
