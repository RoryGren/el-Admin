<p>This is where we will be able to view and edit learner details.</p>
<?php
	$LearnerId = $_POST['learnerId'];
	echo "<p>For LearnerId = $LearnerId</p>";
?>